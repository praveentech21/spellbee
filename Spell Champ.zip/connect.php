<?php

// $conn=mysqli_connect('localhost','codemaster2018','codemaster2018@6464', 'codemaster2018');
// $conn2=mysqli_connect('localhost','codemaster2018','codemaster2018@6464', 'moodle');
$conn=mysqli_connect('localhost','root','', 'codemaster2018');
// $conn2=mysqli_connect('localhost','codemaster2018','codemaster2018@6464', 'moodle');

?>
